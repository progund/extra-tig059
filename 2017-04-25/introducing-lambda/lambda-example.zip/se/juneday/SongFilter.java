package se.juneday;

public interface SongFilter {
    boolean keep(Song s);
}
